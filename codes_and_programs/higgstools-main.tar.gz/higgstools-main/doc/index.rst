Welcome to HiggsTools's documentation!
=======================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   API
   API_mathematica
   Datafile
   alternative_input
   API_fortran


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
